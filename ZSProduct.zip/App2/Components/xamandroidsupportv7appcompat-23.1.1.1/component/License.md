**Xamarin is not responsible for, nor does it grant any licenses to, third-party packages. Some packages may require or install dependencies which are governed by additional licenses.**


This component depends on [Google Android Support Library](http://developer.android.com/tools/support-library/), which is subject to the terms of [Android Software Development Kit License Agreement](http://developer.android.com/sdk/terms.html)

### Xamarin Component for Android Support Library
Xamarin™ Software License Agreement

PLEASE READ THIS AGREEMENT CAREFULLY.  BY INSTALLING, DOWNLOADING OR OTHERWISE USING THE SOFTWARE (INCLUDING ITS COMPONENTS), YOU AGREE TO THE TERMS OF THIS AGREEMENT.  IF YOU DO NOT AGREE WITH THESE TERMS, DO NOT DOWNLOAD, INSTALL OR USE THE SOFTWARE.   

YOU MUST HAVE A SEPARATE VALID XAMARIN SOFTWARE LICENSE AGREEMENT FOR XAMARIN.IOS OR XAMARIN.ANDROID (WHICH MUST BE AN INDIE, BUSINESS, OR ENTERPRISE LICENSE) IN ORDER TO USE THE SOFTWARE COVERED BY THIS AGREEMENT.

#### 1\. RIGHTS AND LICENSES

1.1.	This Xamarin Software License Agreement (“Agreement”) is a legal agreement between You (an entity or a person) and Xamarin Inc. (“Xamarin”).  The software product identified in the title of this Agreement, any media and accompanying documentation (collectively the “Software”) is protected by the copyright laws and treaties of the United States (“U.S.”) and other countries and is subject to the terms of this Agreement.  Any update or support release to the Software that You may download or receive that is not accompanied by a license agreement expressly superseding this Agreement is Software and governed by this Agreement.  If the Software is an update or support release, then You must have validly licensed the version and quantity of the Software being updated or supported in order to install or use the update or support release. If Software You download or receive hereunder is an update or support release for a prior version of the software product identified in the title of this Agreement You had that was subject to the terms of a prior Xamarin software license agreement that differs from this Agreement and may apply to such Software You download or receive hereunder, then this Agreement supersedes such prior license agreement but only with respect to such Software downloaded or received hereunder.

You may only use the Software, as expressly permitted herein, in conjunction with Your Primary Xamarin Software.  As used herein, “Your Primary Xamarin Software” means Xamarin.iOS software or Xamarin.Android software that is both (a) covered by a separate valid Xamarin software license agreement under which You are the licensee (Your “Primary Xamarin License”) and (b) for which You have acquired an Indie license, Business license, or Enterprise license under Your Primary Xamarin License.

1.2.	Components; Other License Terms.  The Software may be comprised of numerous components that may be accompanied by separate license terms.  In that case, the Software is a collective work of Xamarin; although Xamarin may not own the copyright to every component of the Software, Xamarin owns the collective work copyright for the Software.

Some of the components may be open source packages, developed independently, and accompanied by separate license terms.  Your license rights with respect to any individual components accompanied by separate license terms are defined by those terms; nothing in this agreement shall restrict, limit, or otherwise affect any rights or obligations You may have, or conditions to which You may be subject, under such license terms.

1.3.	Instances.  "Instance" means the initial copy of the Software necessary for use of the Software in conjunction with Your use of Your Primary Xamarin Software under Your Primary Xamarin License, and each additional copy (or partial copy) of the Software stored or loaded in memory or virtual memory.  Each Instance of the Software (excluding the Redistributables) must be associated with an Indie Instance license, Business Instance license or Enterprise Instance license of Your Primary Xamarin Software (as “Indie Instance”, “Business Instance”, and “Enterprise Instance” are used in Your Primary Xamarin License) you have acquired, and may only be used by the individual that is permitted to use such Indie Instance, Business Instance, or Enterprise Instance under Your Primary Xamarin License.  

1.4.	Software License Grant.  Subject to the terms and conditions of this Agreement, Xamarin hereby grants to You a world-wide, nonexclusive, non-transferable license to internally use the Software, during the term of this Agreement, solely in conjunction with Your Primary Xamarin Software to develop software applications as permitted in Your Primary Xamarin License (these applications may be referred to as “Apps” herein). Subject to Section 6.1 below , You may use the Software to build a Windows Phone OS version of Your App developed with Your Primary Xamarin Software ('Windows App"), provided that such use is in strict compliance with the terms and conditions of this Agreement and all the terms and conditions applicable to Your Primary Xamarin Software licensed under Your Primary Xamarin License.

1.5.	Redistributables License Grant.  Subject to (a) the terms and conditions of this Agreement and (b) the terms and conditions of Your Primary Xamarin License that restrict or limit Your reproduction and distribution of Primary Redistributables (as defined below) (which terms and conditions, for clarity, will vary depending on whether you have an Indie, Business, or Enterprise license thereunder), which terms and conditions are hereby incorporated into this Agreement by reference and shall apply to Redistributables herein as if they were Primary Redistributables, Xamarin hereby grants to You a world-wide, nonexclusive, non-transferable license to reproduce and distribute the Redistributables (as defined below), during the term of this Agreement, in binary code form only and solely in combination with or in support of Your associated App You developed under Your Primary Xamarin License using the Software in conjunction with Your Primary Xamarin Software.  In the course of Your using the Software in conjunction with Your Primary Xamarin Software, Your Primary Xamarin Software will provide You versions of the following files for Your distribution in combination with or in support of Your associated App: files included in subdirectories of the root “lib” directory of the Software with filenames ending in “.dll”, (each a “Redistributable” and together, the “Redistributables”).  For clarity, the version of each Redistributable that is provided to You for distribution as described above may differ from the version of such file that is present with or in the Software generally or that is provided for distribution with other Apps, and so only the version provided by Your Primary Xamarin Software expressly for distribution with Your associated App as described above will be a “Redistributable” hereunder.  For clarity, the Redistributables are included in the term “Software” hereunder.  

1.6.  	Other License Terms and Restrictions.

The Software is protected by the copyright laws and treaties of the United States ("U.S.") and other countries and is subject to the terms of this Agreement.  The Software is licensed to You, not sold.

The Software may be bundled with other software programs ("Bundled Programs").  Your license rights with respect to Bundled Programs accompanied by separate license terms are defined by those terms; nothing in this Agreement shall restrict, limit, or otherwise affect any rights or obligations You may have, or conditions to which You may be subject, under such license terms.  

Xamarin reserves all rights not expressly granted to You.  You may not: 
(1) reverse engineer, decompile, or disassemble any Software provided that to the extent the foregoing prohibitions are expressly prohibited by applicable statutory law, Xamarin shall retain the maximum protection available against reverse engineering, decompiling, or disassembly under applicable law; 
(2) assign, sublicense, distribute (except as expressly permitted in Section 1.5 for Redistributables), or otherwise transfer any Software to any third party (without limitation, this prohibits You from (a) bundling any Software (including any Xamarin tools, libraries, or runtime) into a competing platform and (b) distributing Xamarin tools, libraries, or runtimes as library, source project, or other unfinished work (i.e., distribution is only permitted for Redistributables and as completely built App that is compiled, signed, and ready for distribution in accordance with Your Primary Xamarin License)); 
(3) reproduce any Software (except as expressly permitted in Section 1.5 for Redistributables); 
(4) create derivative works of, modify, adapt or translate any Software; 
(5) use any Software to provide services for any third party; 
(6) lease, rent, loan, share or otherwise use, or permit use of, any Software by or for any third party; 
(7) use, or permit use of, a single Instance by or for more than one individual;
(8) remove any proprietary notices on or in any Software; 
(9) use any Software in a manner not in accordance with its documentation; or
(10) use any Software in an illegal or fraudulent manner.

1.7.	Evaluation Software.  If the Software is an evaluation version or is provided to You for evaluation purposes, then Your license to use the Software is limited solely to internal evaluation purposes and in accordance with the terms of the evaluation offering under which You received the Software, including any limited evaluation period that may apply (which may also be indicated within the Software).  Upon expiration of the evaluation period, You must discontinue use of the Software, return to an original state any actions performed by the Software, and delete the Software entirely from Your system.  The Software may contain an automatic disabling mechanism that prevents its use after a certain period of time, so You should back up Your system and take other measures to prevent any loss of files or data.  Without limiting the above, You may not use Evaluation Software to create an App.

#### 2\. MAINTENANCE AND SUPPORT

Xamarin has no obligation to provide support or maintenance for the Software.  If Xamarin does provide any such support or maintenance and no separate agreement specifically applies to such support or maintenance, then the terms of this Agreement will govern the provision of such support or maintenance services (“Services“) and Xamarin may cease Services, in whole or part, at any time.  For more information on Xamarin's current support offerings, see http://support.xamarin.com.

#### 3\. OWNERSHIP 

No title to or ownership of the Software is transferred to You.  Xamarin and/or its licensors retain all right, title and interest in and to all intellectual property rights in the Software and Services, including any adaptations or copies thereof.  You acquire only a conditional license to use the Software.

#### 4\. WARRANTY DISCLAIMER

4.1.	Software.  THE SOFTWARE IS PROVIDED “AS IS” WITHOUT ANY WARRANTIES OF ANY KIND.

THE SOFTWARE IS NOT DESIGNED, MANUFACTURED OR INTENDED FOR USE OR DISTRIBUTION WITH ON-LINE CONTROL EQUIPMENT IN HAZARDOUS ENVIRONMENTS REQUIRING FAIL-SAFE PERFORMANCE, SUCH AS IN THE OPERATION OF NUCLEAR FACILITIES, AIRCRAFT NAVIGATION, COMMUNICATION, OR CONTROL SYSTEMS, DIRECT LIFE SUPPORT MACHINES, WEAPONS SYSTEMS, OR OTHER USES IN WHICH FAILURE OF THE SOFTWARE COULD LEAD DIRECTLY TO DEATH, PERSONAL INJURY, OR SEVERE PHYSICAL OR ENVIRONMENTAL DAMAGE.

THE SOFTWARE IS ONLY COMPATIBLE WITH CERTAIN COMPUTERS, OPERATING SYSTEMS AND VERSIONS OF YOUR PRIMARY XAMARIN SOFTWARE. Call Xamarin or Your reseller for information about compatibility.

4.2.	Services.  THE SERVICES (IF ANY) ARE PROVIDED “AS IS” WITHOUT ANY WARRANTIES OF ANY KIND.  As files may be altered or damaged in the course of Xamarin providing technical services, You agree to take appropriate measures to isolate and back up Your systems.

4.3.	Non-Xamarin Products.  The Software may include or be bundled with hardware or other software programs or services licensed or sold by an entity other than Xamarin.  XAMARIN DOES NOT WARRANT NON-XAMARIN PRODUCTS OR SERVICES.  ANY SUCH PRODUCTS OR SERVICES ARE PROVIDED ON AN “AS IS” BASIS.  WARRANTY SERVICE IF ANY FOR NON-XAMARIN PRODUCTS IS PROVIDED BY THE PRODUCT LICENSOR IN ACCORDANCE WITH THE APPLICABLE LICENSOR WARRANTY.

4.4.	General Disclaimer.  EXCEPT AS OTHERWISE RESTRICTED BY LAW, XAMARIN DISCLAIMS AND EXCLUDES ANY AND ALL IMPLIED WARRANTIES, INCLUDING ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE OR NON-INFRINGEMENT.  XAMARIN MAKES NO WARRANTIES, REPRESENTATIONS OR PROMISES.  XAMARIN DOES NOT WARRANT THAT THE SOFTWARE OR SERVICES WILL SATISFY YOUR REQUIREMENTS OR THAT THE OPERATION OF THE SOFTWARE OR SERVICES WILL BE UNINTERRUPTED.  Some jurisdictions do not allow certain disclaimers and limitations of warranties, so portions of the above limitations may not apply to You.  You may also have other rights which vary by state or jurisdiction.  

#### 5\.  LIMITATION OF LIABILITY

5.1.	Consequential Losses.  NEITHER XAMARIN NOR ANY OF ITS LICENSORS, SUBSIDIARIES, OR EMPLOYEES WILL IN ANY CASE BE LIABLE FOR ANY SPECIAL, INCIDENTAL, CONSEQUENTIAL, INDIRECT, TORT, ECONOMIC OR PUNITIVE DAMAGES ARISING OUT OF OR RELATING TO THIS AGREEMENT OR THE USE OF OR INABILITY TO USE THE SOFTWARE OR SERVICES, INCLUDING LOSS OF PROFITS, BUSINESS OR DATA, EVEN IF ADVISED OF THE POSSIBILITY OF THOSE DAMAGES.

5.2.	Direct Damages.  IN NO EVENT WILL XAMARIN'S AGGREGATE LIABILITY FOR DIRECT DAMAGES ARISING OUT OF OR RELATING TO THIS AGREEMENT OR THE USE OF OR INABILITY TO USE THE SOFTWARE OR SERVICES (WHETHER IN ONE INSTANCE OR A SERIES OF INSTANCES) EXCEED FIFTY UNITED STATES DOLLARS ($50 (U.S.)).  

5.3.	Exclusions.  The above exclusions and limitations will not apply to claims relating to death or personal injury.  In those jurisdictions that do not allow the exclusion or limitation of damages, Xamarin's liability shall be limited or excluded to the maximum extent allowed within those jurisdictions.

#### 6\.  GENERAL TERMS

6.1.	Term.  This Agreement becomes effective on the date You legally acquire the Software and will automatically terminate on the earlier of the following: (i)Your breach any of the terms of this Agreement or (ii) the expiration or termination of Your Primary Xamarin License.  

6.2.	Benchmark Testing.  This benchmark testing restriction applies to You if You are a software developer or licensor or if You are performing testing on the Software at the direction of or on behalf of a software developer or licensor.  You may not, without Xamarin's prior written consent not to be unreasonably withheld, publish or disclose to any third party the results of any benchmark test of the Software.  If You are a licensor of products that are functionally similar to or compete with the Software (“Similar Products”), or are acting on behalf of such a licensor, and You publish or disclose benchmark information on the Software in violation of this restriction, then notwithstanding anything to the contrary in the Similar Product's end user license agreement, and in addition to any other remedies Xamarin may have, Xamarin shall have the right to perform benchmark testing on Similar Products and to disclose and publish that benchmark information and You hereby represent that You have authority to grant such right to Xamarin.

6.3.	Open Source.  Nothing in this Agreement shall restrict, limit or otherwise affect any rights or obligations You may have, or conditions to which You may be subject, under any applicable open source licenses to any open source code contained in the Software.  

6.4.	Assignment; Transfer.  Neither this Agreement, nor any rights or obligations hereunder, may be transferred, assigned or delegated without the prior written approval of Xamarin.  Any such transfer, assignment or delegation made in contravention of this paragraph shall be null and void.

6.5.	Law and Jurisdiction.  This Agreement is and will be governed by and construed under the laws of the State of California, U.S., without giving effect to any conflicts of laws provision thereof or of any other jurisdiction that would produce a contrary result.  Any action arising out of or relating to this Agreement may be brought before the courts of competent jurisdiction of the State of California, U.S., and You consent to the jurisdiction of such courts and waive any objections of improper venue or inconvenient forum.  You consent to service of process by mail, nationally-recognized courier service, fax or email, to the contact information you provided to Xamarin at the time of your acquisition of the Software or thereafter.  

6.6.	Entire Agreement.  This Agreement sets forth the entire understanding and agreement between You and Xamarin and may be amended or modified only by a written agreement agreed to by You and an authorized representative of Xamarin.  NO LICENSOR, DISTRIBUTOR, DEALER, RETAILER, RESELLER, SALES PERSON, OR EMPLOYEE IS AUTHORIZED TO MODIFY THIS AGREEMENT OR TO MAKE ANY REPRESENTATION OR PROMISE THAT IS DIFFERENT FROM, OR IN ADDITION TO, THE TERMS OF THIS AGREEMENT.  

6.7.	Waiver.  No waiver of any right under this Agreement will be effective unless in writing, signed by a duly authorized representative of the party to be bound.  No waiver of any past or present right arising from any breach or failure to perform will be deemed to be a waiver of any future right arising under this Agreement.

6.8.	Severability.  If any provision in this Agreement is invalid or unenforceable, that provision will be construed, limited, modified or, if necessary, severed, to the extent necessary, to eliminate its invalidity or unenforceability, and the other provisions of this Agreement will remain unaffected.  

6.9.	Export Compliance.  Any Software or technical information received under this Agreement (collectively, “Received Items”) may be subject to U.S. export controls and the trade laws of other countries.  You agree to comply with all applicable export control regulations and to obtain any required licenses or classification to export, re-export or import Received Items.  You may not use or otherwise export or re-export the Received Items except as authorized by U.S. law and the law of each jurisdiction that applies to Your activities.  Without limiting the foregoing, You agree not to export or re-export any Received Items to (a) entities or persons on the then-current U.S. Treasury Department's list of Specially Designated Nationals, the then-current U.S. Department of Commerce Denied Person’s List or Entity List, or any other U.S. export exclusion list that is then applicable or (b) any embargoed or terrorist country as specified in the U.S. export laws.  By installing, downloading or otherwise using the Received Items, You represent and warrant that You are not located in any such embargoed or terrorist country or on any such exclusion list.  In addition, You agree not to use any Received Items for any purposes prohibited by United States law, including the development, design, manufacture or production of nuclear, missile, or chemical or biological weapons.  Upon request, Xamarin will provide You specific information regarding applicable restrictions.  However, Xamarin assumes no responsibility for Your failure to obtain any necessary export approvals.

6.10.	U.S. Government Restricted Rights.  Use, duplication, or disclosure by the U.S. Government is subject to the restrictions in FAR 52.227-14 (June 1987) Alternate III (June 1987), FAR 52.227-19 (June 1987), or DFARS 252.227-7013 (b) (3) (Nov 1995), or applicable successor clauses.  Contractor/Manufacturer is Xamarin Inc., 430 Pacific Avenue, San Francisco, CA  94133.

6.11.	Headings; Interpretation.  Headings are provided for convenience only and will not be used to interpret the substance of this Agreement.  The use of “include,” “includes,” or “including” herein will be read as if followed by the phrase “without limitation.”

6.12.	Trademarks.  Nothing in this Agreement shall be construed as conferring any right to You to use any name, logo, or other trademark of Xamarin, its affiliates or licensors.

6.13.	Other.  The application of the United Nations Convention of Contracts for the International Sale of Goods is expressly excluded.

© 2016 Xamarin Inc. All Rights Reserved.

Xamarin is a trademark of Xamarin Inc. in the United States and other countries.  

20160301